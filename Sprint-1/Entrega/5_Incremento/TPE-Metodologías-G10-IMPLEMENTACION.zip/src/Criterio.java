

public interface Criterio {
	public boolean evaluar(Solicitud s);
	
	
}
