var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620579738843.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620579738843-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620579738843-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1620579738843.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1620579738843-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1620579738843-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer pageload click ie-background commentable non-processed" customid="Image 1"   datasizewidth="1280.0px" datasizeheight="800.2px" dataX="0.0" dataY="-1.1"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/0945b3f4-0d9b-4c10-af92-358f75eb7962.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Feature-big-2" class="group firer ie-background commentable non-processed" customid="Feature-big-2" datasizewidth="1024.0px" datasizeheight="560.0px" >\
        <div id="s-Bg" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="1024.0px" datasizeheight="560.0px" datasizewidthpx="1024.0" datasizeheightpx="560.0" dataX="128.0" dataY="119.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Title" class="pie richtext autofit firer ie-background commentable non-processed" customid="Title"   datasizewidth="543.5px" datasizeheight="49.0px" dataX="201.0" dataY="158.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Title_0">Materiales reciclables aceptados</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="454.0px" datasizeheight="63.0px" dataX="201.0" dataY="221.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_0">Los materiales aceptados por la cooperativa para el proceso de reciclaje deben ser entregados cumpliendo las siguientes condiciones</span><span id="rtr-s-Paragraph_1">:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_3" class="pie image lockV firer ie-background commentable non-processed" customid="Image_1"   datasizewidth="157.0px" datasizeheight="116.9px" dataX="146.0" dataY="493.0" aspectRatio="0.7446809"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/6b45b30a-8fae-4e7a-b6c8-4f86bd89c991.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_1"   datasizewidth="322.0px" datasizeheight="42.0px" dataX="281.0" dataY="345.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Deben entregarse limpias, secas y aplastadas</span><span id="rtr-s-Paragraph_1_1">.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_4" class="pie image lockV firer ie-background commentable non-processed" customid="Image_2"   datasizewidth="100.0px" datasizeheight="74.5px" dataX="175.0" dataY="313.0" aspectRatio="0.7446809"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/5d41ef16-f98f-4e1b-b905-3d8de1390876.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_5" class="pie image lockV firer ie-background commentable non-processed" customid="Image_3"   datasizewidth="94.0px" datasizeheight="70.0px" dataX="178.0" dataY="409.0" aspectRatio="0.7446808"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/0d676426-0571-49d3-bbeb-b4d19bdd2afb.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_12" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_12"   datasizewidth="96.0px" datasizeheight="42.0px" dataX="280.0" dataY="308.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_12_0">LATAS DE ALUMINIO<br /><br /></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_2"   datasizewidth="322.0px" datasizeheight="38.0px" dataX="281.0" dataY="451.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">Deben entregarse limpias y desarmadas.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_13" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_13"   datasizewidth="96.0px" datasizeheight="28.0px" dataX="280.0" dataY="416.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_13_0">CAJAS DE CARTON</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_3"   datasizewidth="322.0px" datasizeheight="36.0px" dataX="280.0" dataY="551.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">Deben entregarse limpios y secos.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_14" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_14"   datasizewidth="96.0px" datasizeheight="30.0px" dataX="280.0" dataY="521.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_14_0">VIDRIOS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="1024.0px" datasizeheight="70.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="1280.0px" datasizeheight="70.0px" datasizewidthpx="1279.9999999999998" datasizeheightpx="69.99999999999997" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed" customid="Image_1"   datasizewidth="25.0px" datasizeheight="18.0px" dataX="62.0" dataY="26.0"   alt="image" systemName="./images/8b441dac-cc9c-4d9b-992e-28aa2f0b3ba8.svg" overlay="#A18489">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="18px" version="1.1" viewBox="0 0 25 18" width="25px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Menu Burger Icon</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_2-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#333333" id="Header-#2" transform="translate(-120.000000, -26.000000)">\
            	            <g id="s-Image_2-Top">\
            	                <path d="M145,26 L145,28 L120,28 L120,26 L145,26 Z M145,42 L145,44 L120,44 L120,42 L145,42 Z M145,34 L145,36 L120,36 L120,34 L145,34 Z" id="s-Image_2-Menu-Burger-Icon" style="fill:#A18489 !important;" />\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Image_35" class="pie image firer click ie-background commentable non-processed" customid="Image_35"   datasizewidth="30.0px" datasizeheight="35.0px" dataX="1191.0" dataY="18.0"   alt="image" systemName="./images/9a88efc3-0287-4747-885b-6f4430cc1b5e.svg" overlay="#A18488">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
          	    <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
          	    <title>user</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_35-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#666666" id="s-Image_35-user">\
          	            <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" id="s-Image_35-Fill-1" style="fill:#A18488 !important;" />\
          	            <path d="M9.63332578,11.4682653 L7.36665911,11.4682653 C5.40191244,11.4682653 3.55087689,12.2442836 2.15461022,13.65341 C0.765181333,15.0556274 -7.55555556e-06,16.9065514 -7.55555556e-06,18.8653527 C-7.55555556e-06,19.1764059 0.253708,19.4285827 0.566659111,19.4285827 L16.4333258,19.4285827 C16.7462769,19.4285827 16.9999924,19.1764059 16.9999924,18.8653527 C16.9999924,16.9065514 16.2348036,15.0556274 14.8453747,13.65341 C13.449108,12.2442836 11.5981102,11.4682653 9.63332578,11.4682653 Z" id="s-Image_35-Fill-3" style="fill:#A18488 !important;" />\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="125.5px" datasizeheight="50.0px" dataX="577.3" dataY="-0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">C R U T</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="340.2px" datasizeheight="19.0px" dataX="469.9" dataY="40.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Cooperativa de Recuperadores Urbanos de Tandil</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Options" class="group firer ie-background commentable non-processed" customid="Options" datasizewidth="345.0px" datasizeheight="181.0px" >\
        <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_3"   datasizewidth="345.0px" datasizeheight="46.0px" datasizewidthpx="345.0" datasizeheightpx="46.0" dataX="0.0" dataY="70.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0">Solicitar entrega de materiales</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_4" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_4"   datasizewidth="345.0px" datasizeheight="46.0px" datasizewidthpx="345.0" datasizeheightpx="46.0" dataX="0.0" dataY="115.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0">Listado de ofertas de transporte</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_5" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_5"   datasizewidth="345.0px" datasizeheight="46.0px" datasizewidthpx="345.0" datasizeheightpx="46.0" dataX="0.0" dataY="160.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_5_0">Ofrecer transporte</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_6" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_4"   datasizewidth="345.0px" datasizeheight="46.0px" datasizewidthpx="345.0" datasizeheightpx="46.0" dataX="0.0" dataY="206.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_6_0">Postularse para hacer uso de oferta de transporte</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_6" class="pie image firer ie-background commentable non-processed" customid="Image"   datasizewidth="395.9px" datasizeheight="211.6px" dataX="788.0" dataY="285.2"  rotationdeg="90" alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/9f8683e3-eec4-4acc-9af1-2e3e15b7d07f.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_10" class="pie image firer ie-background commentable non-processed" customid="Image_10"   datasizewidth="37.0px" datasizeheight="33.0px" dataX="25.0" dataY="748.0"   alt="image" systemName="./images/bf564f58-51f5-448d-839e-5b359567080a.svg" overlay="#000000">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="24px" version="1.1" viewBox="0 0 24 24" width="24px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Facebook Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_10-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#DDDDDD" id="s-Image_10-Components" transform="translate(-615.000000, -934.000000)">\
          	            <g id="s-Image_10-Social" transform="translate(100.000000, 849.000000)">\
          	                <g id="s-Image_10-Rounded-Icons" transform="translate(515.000000, 85.000000)">\
          	                    <g id="s-Image_10-Facebook-Icon">\
          	                        <path d="M12,24 C5.372583,24 0,18.627417 0,12 C0,5.372583 5.372583,0 12,0 C18.627417,0 24,5.372583 24,12 C24,18.627417 18.627417,24 12,24 Z M14.726776,8.76861702 L15,7.19946809 C14.4945355,7.02659574 13.5655738,7 13.0464481,7 C11.5300546,7 10.9016393,8.11702128 10.9016393,9.46010638 L10.9016393,10.3510638 L10,10.3510638 L10,12.1196809 L10.9016393,12.1196809 L10.9016393,17 L12.7322404,17 L12.7322404,12.1196809 L14.5491803,12.1196809 L14.5491803,10.3510638 L12.7322404,10.3510638 L12.7322404,9.30053191 C12.7322404,8.86170213 13.4972678,8.6356383 13.852459,8.6356383 C14.1393443,8.6356383 14.4535519,8.68882979 14.726776,8.76861702 Z" style="fill:#000000 !important;" />\
          	                    </g>\
          	                </g>\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_31" class="pie image firer ie-background commentable non-processed" customid="Image_31"   datasizewidth="37.0px" datasizeheight="33.0px" dataX="75.0" dataY="748.0"   alt="image" systemName="./images/91ac1ec2-d3ed-4596-9300-ec262398cd3f.svg" overlay="#000000">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="24px" version="1.1" viewBox="0 0 24 24" width="24px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Twitter Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_31-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#DDDDDD" id="s-Image_31-Components" transform="translate(-649.000000, -934.000000)">\
          	            <g id="s-Image_31-Social" transform="translate(100.000000, 849.000000)">\
          	                <g id="s-Image_31-Rounded-Icons" transform="translate(515.000000, 85.000000)">\
          	                    <g id="s-Image_31-Twitter-Icon" transform="translate(34.000000, 0.000000)">\
          	                        <path d="M12,24 C5.372583,24 0,18.627417 0,12 C0,5.372583 5.372583,0 12,0 C18.627417,0 24,5.372583 24,12 C24,18.627417 18.627417,24 12,24 Z M15.5433071,9.40709178 C15.5433071,9.40709178 15.5433071,9.30658522 15.5433071,9.40709178 C15.0708661,8.904559 14.503937,8.70354589 13.9370079,8.80405244 C14.503937,8.70354589 14.7874016,8.50253278 14.8818898,8.40202622 C14.8818898,8.30151967 14.8818898,8.20101311 14.7874016,8.20101311 C14.503937,8.20101311 14.2204724,8.30151967 14.0314961,8.40202622 C14.3149606,8.20101311 14.4094488,8.10050656 14.4094488,8 C14.1259843,8 13.8425197,8.20101311 13.4645669,8.50253278 C13.5590551,8.30151967 13.6535433,8.20101311 13.5590551,8.10050656 C13.3700787,8.20101311 13.2755906,8.30151967 13.1811024,8.50253278 C12.8976378,8.80405244 12.7086614,9.00506555 12.6141732,9.30658522 C12.2362205,10.0101311 11.9527559,10.6131704 11.7637795,11.3167163 L11.6692913,11.3167163 C11.480315,11.0151967 11.1968504,10.713677 10.8188976,10.5126639 C10.4409449,10.2111442 9.96850394,10.0101311 9.4015748,9.70861144 C8.83464567,9.40709178 8.26771654,9.10557211 7.60629921,8.904559 C7.60629921,9.60810489 7.88976378,10.2111442 8.5511811,10.6131704 C8.36220472,10.6131704 8.07874016,10.6131704 7.88976378,10.713677 C7.88976378,11.3167163 8.36220472,11.8192491 9.21259843,12.0202622 C8.92913386,12.0202622 8.64566929,12.1207688 8.36220472,12.3217819 C8.64566929,12.9248212 9.11811024,13.1258343 9.87401575,13.1258343 C9.77952756,13.2263409 9.59055118,13.3268474 9.59055118,13.3268474 C9.49606299,13.427354 9.4015748,13.6283671 9.49606299,13.8293802 C9.68503937,14.1308999 9.87401575,14.2314064 10.3464567,14.2314064 C9.68503937,14.9349523 8.83464567,15.3369785 7.88976378,15.236472 C7.32283465,15.236472 6.66141732,14.9349523 6,14.331913 C6.66141732,15.3369785 7.60629921,16.141031 8.74015748,16.6435638 C10.0629921,17.04559 11.3858268,17.1460965 12.6141732,16.7440703 C13.8425197,16.3420441 14.976378,15.5379917 15.8267717,14.4324196 C16.2047244,13.8293802 16.488189,13.2263409 16.5826772,12.6233016 C17.2440945,12.6233016 17.7165354,12.4222884 18,12.0202622 C17.8110236,12.1207688 17.3385827,12.1207688 16.6771654,11.9197557 C17.3385827,11.8192491 17.8110236,11.618236 17.9055118,11.2162098 C17.4330709,11.4172229 16.9606299,11.4172229 16.488189,11.2162098 C16.3937008,10.5126639 16.1102362,9.90962455 15.5433071,9.40709178 Z" style="fill:#000000 !important;" />\
          	                    </g>\
          	                </g>\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_25" class="pie image firer ie-background commentable non-processed" customid="Image_25"   datasizewidth="25.0px" datasizeheight="32.0px" dataX="125.0" dataY="748.0"   alt="image" systemName="./images/4e067777-6115-42fb-8406-19b5c53626a3.svg" overlay="#000000">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="32px" version="1.1" viewBox="0 0 25 32" width="25px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Pins</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_25-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#282828" id="s-Image_25-Components" transform="translate(-770.000000, -928.000000)">\
          	            <g id="s-Image_25-Social" transform="translate(100.000000, 849.000000)">\
          	                <g id="s-Image_25-Pins" transform="translate(670.000000, 79.000000)">\
          	                    <g id="s-Image_25-Big-Pin">\
          	                        <path d="M12.5,0 C5.596,0 0,5.535 0,12.363 C0,21.79 10.117,32 12.541,32 C14.965,32 25,21.79 25,12.363 C25,5.535 19.404,0 12.5,0 L12.5,0 Z M12.5,18.093 C9.326,18.093 6.753,15.549 6.753,12.409 C6.753,9.27 9.326,6.725 12.5,6.725 C15.674,6.725 18.247,9.27 18.247,12.409 C18.247,15.549 15.674,18.093 12.5,18.093 L12.5,18.093 Z" style="fill:#000000 !important;" />\
          	                    </g>\
          	                </g>\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="307.0px" datasizeheight="182.0px" datasizewidthpx="306.9999999999998" datasizeheightpx="182.0" dataX="973.0" dataY="70.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="29.0px" dataX="1019.5" dataY="90.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Usuario"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="29.0px" dataX="1020.0" dataY="146.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Contrase&ntilde;a"/></div></div>  </div></div></div>\
      <div id="s-Button_1" class="pie button multiline manualfit firer commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1093.0" dataY="214.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Login</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;