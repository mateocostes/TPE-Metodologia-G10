(function(window, undefined) {

  var jimLinks = {
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);